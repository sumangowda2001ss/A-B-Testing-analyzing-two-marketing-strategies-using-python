# A-B-Testing-analyzing-two-marketing-strategies-using-python

A-B-Testing-analyzing-two-marketing-strategies-using-python
A/B Testing means analyzing two marketing strategies to choose the best marketing strategy that can convert more traffic into sales (or more traffic into your desired goal) effectively and efficiently.

In A/B testing, we analyze the results of two marketing strategies to choose the best one for future marketing campaigns. For example, when I started an ad campaign on Instagram to promote my Instagram post for the very first time, my target audience was different from the target audience of my second ad campaign. After analyzing the results of both ad campaigns, I always preferred the audience of the second ad campaign as it gave better reach and followers than the first one.

DATA SET
The dataset we are using here contains two data files about two marketing campaigns.
1. control_data
2. Test_data


